﻿namespace Shop.BusinessLayer.Models.Goods.ResponseModels
{
    public class GoodsResponseModel
    {
        public byte Article { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
