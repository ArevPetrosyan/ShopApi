﻿namespace Shop.BusinessLayer.Models.Orders.ResponseModels
{
    public class OrderedGoods
    {
        public string GoodsName { get; set; }
        public byte Count { get; set; }
    }
}
