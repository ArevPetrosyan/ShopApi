﻿namespace Shop.BusinessLayer.Exceptions
{
    public class OrderAmountExceededException : ShopBaseException
    {
    }
}
