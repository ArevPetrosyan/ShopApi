﻿namespace Shop.BusinessLayer.Exceptions
{
    public class OrderItemsCountException : ShopBaseException
    {
    }
}
