﻿namespace Shop.BusinessLayer.Exceptions
{
    public class OrderNumberUsedException : ShopBaseException
    {
    }
}
