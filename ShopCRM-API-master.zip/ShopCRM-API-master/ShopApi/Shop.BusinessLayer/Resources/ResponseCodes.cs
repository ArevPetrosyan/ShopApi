﻿namespace Shop.BusinessLayer.Resources
{
    public class ResponseCodes
    {

    }
}
