﻿namespace Shop.BusinessLayer.Interfaces
{
    public interface IShopServices
    {
        T GetService<T>();
    }
}
